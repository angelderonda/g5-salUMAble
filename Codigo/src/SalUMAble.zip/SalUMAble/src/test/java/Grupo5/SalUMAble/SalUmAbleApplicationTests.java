package Grupo5.SalUMAble;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SalUmAbleApplicationTests {

	@Test
	void contextLoads() {
	}

}
