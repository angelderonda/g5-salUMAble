package Grupo5.SalUMAble.MODEL;

public enum EstadoPaciente {
	EN_CONSULTA, EN_ESPERA, ATENDIDO;
}
